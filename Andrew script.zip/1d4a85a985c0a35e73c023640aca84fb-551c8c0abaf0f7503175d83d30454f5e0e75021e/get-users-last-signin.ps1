# Increase the function capacity
$MaximumFunctionCount = 8192

# Ensure the ImportExcel module is installed
if (-not (Get-Module -ListAvailable -Name ImportExcel)) {
    try {
        Write-Host "Installing ImportExcel module..."
        Install-Module -Name ImportExcel -Scope CurrentUser -Force -ErrorAction Stop
        Write-Host "Successfully installed the ImportExcel module."
    } catch {
        Write-Error "Failed to install the ImportExcel module. Error: $_"
        exit 1
    }
}

# Import the required modules
try {
    Write-Host "Importing Microsoft.Graph module..."
    Import-Module Microsoft.Graph -ErrorAction Stop
    Write-Host "Successfully imported Microsoft.Graph module."

    Write-Host "Importing ImportExcel module..."
    Import-Module ImportExcel -ErrorAction Stop
    Write-Host "Successfully imported ImportExcel module."
} catch {
    Write-Error "Failed to import necessary modules. Error: $_"
    exit 1
}

# Define the SKUs for M365 Business Premium and M365 F3
$skus = @{
    "cbdc14ab-d96c-4c30-b9f4-6ada7cdc1d46" = "M365 Business Premium"
    "66b55226-6b4f-492c-910c-a3b7a3c9d993" = "M365 F3"
}

# Initialize an array to hold user details
$userDetailsArray = @()

# Define the function to get user details
function Get-UserDetails {
    param (
        [string]$userId
    )

    try {
        $user = Get-MgUser -UserId $userId -Property "DisplayName,UserPrincipalName,Department,JobTitle,Manager,SignInActivity,AccountEnabled" -ExpandProperty "Manager"
        return $user
    } catch {
        Write-Error "Failed to get user details for $userId. Error: $_"
        return $null
    }
}

# Define the function to get manager display name
function Get-ManagerDisplayName {
    param (
        [string]$managerId
    )

    try {
        $manager = Get-MgUser -UserId $managerId -Property "DisplayName"
        return $manager.DisplayName
    } catch {
        Write-Error "Failed to get manager details for $managerId. Error: $_"
        return $null
    }
}

# Authenticate to Microsoft Graph with necessary permissions
Write-Host "Authenticating to Microsoft Graph..."
Connect-MgGraph -Scopes "User.Read.All", "Directory.Read.All"
Write-Host "Successfully authenticated to Microsoft Graph."

try {
    # Get all users
    Write-Host "Retrieving all users..."
    $users = Get-MgUser -All -Property "DisplayName,UserPrincipalName,Department,JobTitle,Manager,SignInActivity,AccountEnabled" -ExpandProperty "Manager"
    Write-Host "Successfully retrieved all users."

    foreach ($user in $users) {
        Write-Host "Processing user: $($user.DisplayName) ($($user.UserPrincipalName))"
        try {
            # Get the license details for the user
            $licenses = Get-MgUserLicenseDetail -UserId $user.Id

            # Check if the user has one of the specified SKUs
            $userLicenses = @()
            foreach ($license in $licenses.SkuId) {
                if ($skus.ContainsKey($license)) {
                    $userLicenses += $skus[$license]
                }
            }

            if ($userLicenses.Count -gt 0) {
                # Get detailed user information
                $userDetails = Get-UserDetails -userId $user.Id

                if ($userDetails -ne $null) {
                    # Get manager's display name
                    $managerDisplayName = $null
                    if ($userDetails.Manager -ne $null -and $userDetails.Manager.Id -ne $null) {
                        $managerDisplayName = Get-ManagerDisplayName -managerId $userDetails.Manager.Id
                    }

                    # Prepare user details
                    $signInActivity = $userDetails.SignInActivity
                    $userDetail = [PSCustomObject]@{
                        DisplayName              = $userDetails.DisplayName
                        UPN                      = $userDetails.UserPrincipalName
                        Department               = $userDetails.Department
                        JobTitle                 = $userDetails.JobTitle
                        Manager                  = $managerDisplayName
                        SignInBlocked            = !$userDetails.AccountEnabled
                        LastInteractiveSignIn    = $signInActivity.LastSignInDateTime
                        LastNonInteractiveSignIn = $signInActivity.LastNonInteractiveSignInDateTime
                        Licenses                 = [string]::Join(",", $userLicenses)
                    }
                    $userDetailsArray += $userDetail
                }
            }
        } catch {
            Write-Error "Failed to process user $($user.Id). Error: $_"
        }
    }

    # Generate filename with current date and time
    $currentDateTime = Get-Date -Format "yyyy.MM.dd-HH.mm"
    $filename = "User Last Signin - $currentDateTime.xlsx"

    # Export user details to Excel
    Write-Host "Exporting user details to Excel file: $filename"
    $userDetailsArray | Export-Excel -Path $filename -AutoSize
    Write-Host "Successfully exported user details to $filename."

} catch {
    Write-Error "An error occurred during the script execution. Error: $_"
}
